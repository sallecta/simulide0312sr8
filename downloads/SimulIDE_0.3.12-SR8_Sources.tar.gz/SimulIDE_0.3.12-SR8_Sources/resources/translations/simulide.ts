<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ADC</name>
    <message>
        <source>ADC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Other Logic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AVRComponent</name>
    <message>
        <source>AVR</source>
        <translation type="unfinished">AVR</translation>
    </message>
    <message>
        <source>Micro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Only 1 Mcu allowed
 to be in the Circuit.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AVRComponentPin</name>
    <message>
        <source>Register descriptor file for this AVR processor %1 is corrupted - cannot attach pin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Register descriptor file for this AVR processor %1 is corrupted - cannot attach pin 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pin is not initialized properly:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Amperimeter</name>
    <message>
        <source>Amperimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Meters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AndGate</name>
    <message>
        <source>And Gate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Gates</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>App::Property</name>
    <message>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ReactStep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NoLinStep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NoLinAcc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show ScrollBars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Z Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vref</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Impedance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PNP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Capacitance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show_Cap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Freq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Amp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zener Volt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cols</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Control Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inductance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Ind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Key Labels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CS Active Low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MaxCurrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grounded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input High V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input Low V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input Imped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Out High V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Out Low V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Out Imped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inverted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tristate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock Inverted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset Inverted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert Inputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S R Inverted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Num Inputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Num Bits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Volt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RDSon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>P Channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depletion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Power Pins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value Ohm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PlotterCh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rcoil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Itrig</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Poles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Norm Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show res</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NumDisplays</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CommonCathode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Steps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fixed Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volt Base</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duty Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Avra Inc Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drive Circuit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compiler Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tab Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spaces Tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Spaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Board</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Board</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Num Outputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Functions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Arduino</name>
    <message>
        <source>Arduino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Micro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Only 1 Mcu allowed
 to be in the Circuit.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioOut</name>
    <message>
        <source>Audio Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AvrProcessor</name>
    <message>
        <source>File Not Found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file &quot;%1&quot; was not found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Unable to load IHEX file %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to load firmware: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 should be .hex or .elf
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning on load firmware: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incompatible firmware: compiled for %1 and your processor is %2
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The processor model is not specified.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not Create AVR Processor: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wrong firmware!!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unkown Error:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File %1 is not in valid ELF format
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>B16AsmDebugger</name>
    <message>
        <source>Cannot write file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BJT</name>
    <message>
        <source>BJT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseDebugger</name>
    <message>
        <source>Debugger already running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop active session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uploading: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FirmWare Uploaded to </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Compiler toolchain directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Using Compiler Path: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>: ToolChain not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right-Click on Document Tab to set Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: No Mcu in Simulator... </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BcdTo7S</name>
    <message>
        <source>Bcd To 7S.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Converters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BcdToDec</name>
    <message>
        <source>Bcd To Dec.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Converters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BinCounter</name>
    <message>
        <source>Counter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Arithmetic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Buffer</name>
    <message>
        <source>Buffer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Gates</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Bus</name>
    <message>
        <source>Bus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Other Logic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Capacitor</name>
    <message>
        <source>Capacitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Passive</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Chip</name>
    <message>
        <source>Cannot read file:
%1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot set file:
%1
to DomDocument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error reading Chip file:
%1
No valid Chip</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Circuit</name>
    <message>
        <source>Load Circuit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Circuits (*.simu);;All files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot read file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot set file %1
to DomDocument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot write file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill Of Materials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Subcircuit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2 Package Pins connected together</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CircuitView</name>
    <message>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import Circuit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Circuit as Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create SubCircuit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bill of Materials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save as Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Circuit Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Generated by SimulIDE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CircuitWidget</name>
    <message>
        <source>New C&amp;ircuit	Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new Circuit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open Circuit	Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open an existing Circuit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save Circuit	Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save the Circuit to disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Circuit &amp;As...	Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save the Circuit under a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Power Circuit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Power the Circuit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Online Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
Circuit has been modified.
Do you want to save your changes?
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Circuit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Circuit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Circuits (*.simu);;All files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Circuit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Circuit ERROR!!!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About SimulIDE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>    Real Speed: Debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>    Real Speed: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Clock</name>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sources</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CodeEditor</name>
    <message>
        <source> File: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File recognized as: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File type not supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>     SUCCESS!!! Compilation Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>     ERROR!!! Compilation Faliled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uploading: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
Error:  Mcu Deleted while Debugging!!
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Starting Debbuger...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: No Mcu in Simulator... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: No Debugger Suited for this File... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: No File... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error Compiling... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error Loading Firmware... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debbuger Started </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debbuger Stopped </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CodeEditorWidget</name>
    <message>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColorCombo</name>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Component</name>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate CW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate CCW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rotate 180</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal Flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vertical Flip</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ComponentPlugins</name>
    <message>
        <source>Manage Components</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ComponentSelector</name>
    <message>
        <source>    Loading Component sets at:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot read file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot set file %1
to DomDocument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>        Loaded Component set:           </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage Components</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConnectorLine</name>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CurrSource</name>
    <message>
        <source>Current Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sources</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DAC</name>
    <message>
        <source>DAC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Other Logic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DecToBcd</name>
    <message>
        <source>Dec. To Bcd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Converters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Demux</name>
    <message>
        <source>Demux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Converters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Diode</name>
    <message>
        <source>Diode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditDialog</name>
    <message>
        <source>Pin Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pin Id:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert Pin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unused Pin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Pin </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorWindow</name>
    <message>
        <source>Load File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Document As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot write file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
The Document has been modified.
Do you want to save your changes?
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set Compiler Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New	Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open...	Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open an existing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save	Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save the document to disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save &amp;As...	Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save the document under a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exit the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cu&amp;t	Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut the current selection&apos;s contents to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Copy	Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy the current selection&apos;s contents to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Paste	Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste the clipboard&apos;s contents into the current selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo	Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo the last action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo	Ctrl+Shift+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo the last action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run To Breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run to next breakpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>StepOver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step Over</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop Debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compile Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UpLoad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Firmware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files (*);;Arduino (*.ino);;Asm (*.asm);;GcBasic (*.gcb)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Ellipse</name>
    <message>
        <source>Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileBrowser</name>
    <message>
        <source>Add Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open in editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Hidden</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileWidget</name>
    <message>
        <source>cd Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FindReplaceDialog</name>
    <message>
        <source>Find/Replace</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FindReplaceForm</name>
    <message>
        <source>no match found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replaced %1 occurrence(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find/Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Find:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R&amp;eplace with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D&amp;irection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Case sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Whole words only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R&amp;egular Expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FlipFlopD</name>
    <message>
        <source>FlipFlop D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Memory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FlipFlopJK</name>
    <message>
        <source>FlipFlop JK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Memory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Frequencimeter</name>
    <message>
        <source>Frequencimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Meters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FullAdder</name>
    <message>
        <source>Full Adder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Arithmetic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Function</name>
    <message>
        <source>Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Arithmetic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Function:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Ground</name>
    <message>
        <source>Ground (0 V)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sources</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Hd44780</name>
    <message>
        <source>Hd44780</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>I2CRam</name>
    <message>
        <source>I2C Ram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Memory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>I2CToParallel</name>
    <message>
        <source>I2C to Parallel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Converters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Inductor</name>
    <message>
        <source>Inductor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Passive</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InoDebugger</name>
    <message>
        <source>Cannot write file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ItemLibrary</name>
    <message>
        <source>Gates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arithmetic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Memory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Converters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other Logic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sensors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Micro</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyPad</name>
    <message>
        <source>KeyPad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switches</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Ks0108</name>
    <message>
        <source>Ks0108</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LatchD</name>
    <message>
        <source>Latch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Memory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Led</name>
    <message>
        <source>Led</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LedBar</name>
    <message>
        <source>LedBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LedMatrix</name>
    <message>
        <source>LedMatrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Line</name>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LineNumberArea</name>
    <message>
        <source>Add BreakPoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove BreakPoint</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Lm555</name>
    <message>
        <source>lm555</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Other Logic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogicInput</name>
    <message>
        <source>Fixed Volt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sources</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Components</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RamTable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File explorer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Qt5SerialPort is not installed in your system

    Mcu SerialPort will not work
    Just Install libQt5SerialPort package
    To have Mcu Serial Port Working</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugin Error:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>McuComponent</name>
    <message>
        <source>Cannot read file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot set file %1
to DomDocument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load firmware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload firmware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Serial Monitor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close Serial Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Serial Port.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close Serial Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Firmware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No File to reload </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load EEPROM data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save EEPROM data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hex Files (*.hex);;ELF Files (*.elf);;All files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MemData</name>
    <message>
        <source>Load Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot write file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Memory</name>
    <message>
        <source>Ram/Rom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Memory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Mosfet</name>
    <message>
        <source>Mosfet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Mux</name>
    <message>
        <source>Mux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Converters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MuxAnalog</name>
    <message>
        <source>Analog Mux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OpAmp</name>
    <message>
        <source>OpAmp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OrGate</name>
    <message>
        <source>Or Gate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Gates</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Oscope</name>
    <message>
        <source>Oscope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Meters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PICComponent</name>
    <message>
        <source>Micro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Only 1 Mcu allowed
 to be in the Circuit.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Pcd8544</name>
    <message>
        <source>Pcd8544</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PicProcessor</name>
    <message>
        <source>File Not Found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file &quot;%1&quot; was not found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unkown Error:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not Create Pic Processor: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not Load: &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlotterWidget</name>
    <message>
        <source>Max </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Min  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scale:   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tracks: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Potentiometer</name>
    <message>
        <source>Potentiometer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Passive</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Probe</name>
    <message>
        <source>Probe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Meters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove from Plotter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plotter Channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 4</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <source>Here will be some help ..............................................
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Push</name>
    <message>
        <source>Push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switches</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPropertyModel</name>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Rail</name>
    <message>
        <source>Rail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sources</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RamTable</name>
    <message>
        <source>Reg.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load VarSet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save VarSet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VarSets (*.vst);;All files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot write file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Rectangle</name>
    <message>
        <source>Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RelaySPST</name>
    <message>
        <source>Relay (all)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switches</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Resistor</name>
    <message>
        <source>Resistor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Passive</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResistorDip</name>
    <message>
        <source>ResistorDip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Passive</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SR04</name>
    <message>
        <source>HC-SR04</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sensors</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SerialPortWidget</name>
    <message>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacturer: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serial number: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connected to %1 : %2, %3, %4, %5, %6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Even</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Odd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manufacturer:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serial number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flow control:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop bits:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BaudRate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Data bits:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Servo</name>
    <message>
        <source>Servo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SevenSegment</name>
    <message>
        <source>7 Segment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SevenSegmentBCD</name>
    <message>
        <source>7 Seg BCD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Other Logic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShiftReg</name>
    <message>
        <source>Shift Reg.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Arithmetic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Stepper</name>
    <message>
        <source>Stepper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubCircuit</name>
    <message>
        <source>Subcircuit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot read file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot set file %1
to DomDocument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error reading Subcircuit file: %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are no data files for </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubPackage</name>
    <message>
        <source>Package</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
Package has been modified.
Do you want to save your changes?
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move Pin </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Pin </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Package</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Package</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Package File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Packages (*.package);;All files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot write file %1:
%2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Pin </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Switch</name>
    <message>
        <source>Switches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch (all)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SwitchDip</name>
    <message>
        <source>Switches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch Dip</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TerminalWidget</name>
    <message>
        <source>Send Text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>    Send Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>    Print:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Value </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Received From Micro:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sent to Micro:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextComponent</name>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VoltReg</name>
    <message>
        <source>Volt. Regulator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VoltSource</name>
    <message>
        <source>Volt. Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sources</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Voltimeter</name>
    <message>
        <source>Voltimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Meters</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WaveGen</name>
    <message>
        <source>Wave Gen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sources</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>XorGate</name>
    <message>
        <source>Xor Gate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic/Gates</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>elCapacitor</name>
    <message>
        <source>Electrolytic Capacitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Passive</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>xmlfile</name>
    <message>
        <source>Logic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>

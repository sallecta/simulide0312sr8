
#ifndef CONFIG_H
#define  CONFIG_H

#define PACKAGE_VERSION "0"

#define PRINTF_INT64_MODIFIER "ll"

#define FALSE false
#define TRUE  true

#define INVALID_VALUE 0xffffffff

#define MAX_PROGRAM_MEMORY 0xffff

#endif
